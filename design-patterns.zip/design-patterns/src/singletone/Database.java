package singletone;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
public class Database {
    private static Database instance;
    private static Connection connection;

    private Database() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/my_server?autoReconnect=true&useSSL=false", "admin", "admin");
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    public static Database getInstance() {
        if (Database.instance == null)
            instance = new Database();
        return Database.instance;
    }
    public void query (String sql){
        try {
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(sql);
            while (result.next()) {
                System.out.println("name: " + result.getString("name"));
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
