package builder;

public class House {
    private boolean garage;
    private int rooms;
    private int windows;
    private int doors;
    public static class Builder{
        private int windows;
        private int doors;
        private int rooms;
        private boolean garage;
        public Builder() {
        }

        public Builder Windows(int windows) {
            this.windows = windows;
            return this;
        }
        public Builder Doors(int doors) {
            this.doors = doors;
            return this;
        }
        public Builder Rooms(int rooms) {
            this.rooms = rooms;
            return this;
        }
        public Builder Garage(boolean garage){
            this.garage = garage;
            return this;
        }
        public House buildHouse(){
            House housedetails = new House();
            housedetails.garage = this.garage;
            housedetails.windows = this.windows;
            housedetails.rooms = this.rooms;
            housedetails.doors = this.doors;
            return housedetails;
        }
    }
}