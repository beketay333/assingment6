package builder;

public class Application {
    public static void main(String[] args) {
        House house;
        house = new House.Builder().Rooms(3).Windows(2).Doors(2).Garage(false).buildHouse();
        System.out.println("House: " + house);
    }
}