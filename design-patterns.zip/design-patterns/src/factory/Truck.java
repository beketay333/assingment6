package factory;

public class Truck implements Transport{
    public void deliver(){
        System.out.println("Deliver by land in a box.");
    }
}
