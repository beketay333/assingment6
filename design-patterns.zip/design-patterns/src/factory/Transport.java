package factory;

public interface Transport {
    void deliver();
}
