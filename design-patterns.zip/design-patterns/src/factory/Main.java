package factory;

public class Main {
    public static void main(String[] args) {
        Logistics first = new SeaLogistics();
        first.planDelivery();
        Logistics second = new RoadLogistics();
        second.planDelivery();
    }
}
